//
//  ViewController.swift
//  MyWeatherApp
//
//  Created by Fekadu Abebe on 9/22/17.
//  Copyright © 2017 Fekadu Abebe. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UISearchBarDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var cityLabel: UILabel!
    
    @IBOutlet weak var conditionLabel: UILabel!
    
    @IBOutlet weak var degreeLable: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    var degree: Int!
    var condition: String!
    var imgURL: String!
    var city: String!
    var exists: Bool = true
    var location: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        searchBar.delegate = self
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let urlRequest = URLRequest(url: URL(string:"http://api.apixu.com/v1/current.json?key=d6e39ac9697649a1835150959172709&q=\(String(describing:  searchBar.text?.replacingOccurrences(of: "", with: "%20")))")!)
        let task = URLSession.shared.dataTask(with: urlRequest){
            (data, respond, error) in
            if error == nil {
                do{
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String:AnyObject]
                    if let current = json["current"] as? [String: AnyObject]{
                        if let temp = current["temp_c"] as? Int {
                            self.degree = temp
                            
                            
                        }
                        if let condition = current["condition"] as? [String: AnyObject]{
                            self.condition = condition["text"]as! String
                            self.imgURL = condition["icon"] as! String
                        }
                    }
                    if let location = json["location"] as? [String: AnyObject]{
                        self.city = location["name"] as! String
                    }
                    if let _ = json["error"]{
                        self.exists = false
                    }
                    DispatchQueue.main.async{
                        if self.exists{
                            self.degreeLable.text = self.degree.description
                            self.cityLabel.text = self.city
                            self.conditionLabel.text = self.condition
                        }else{
                            
                            self.degreeLable.isHidden = true
                            self.conditionLabel.isHidden = true
                            self.imageView.isHidden = true
                            self.cityLabel.text = "not found"
                            self.exists = true
                        }
                        
                    }
                }catch let jsonError {
                    print(jsonError.localizedDescription)
                    
                }
                
            }
            
        }
        task.resume()
    }
}
