//
//  Networking.swift
//  Network
//
// Created by Fekadu Abebe on 9/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//
import Foundation
import UIKit

class Networking:Codable{
   
    static func mynetwork(_ array:[characters],_ url:String, completion: @escaping ([characters]?, Error?)->()){
        guard let myurl = URL(string: url)else{return}
        let session = URLSession.shared
        let task = session.dataTask(with: myurl){
            (data, response, error) in
            guard error == nil else{return}
            guard let httpResponse = response as? HTTPURLResponse else{return}
            guard httpResponse.statusCode == 200 else{return}
            guard let data = data else{return}
            
            do{
                let myDecoder = JSONDecoder()
                
                let information = try myDecoder.decode(info.self, from: data)
                let Characters = information.results
                
                if information.next == nil{
                completion(array + Characters,nil)
                }
                else if information.next != nil{
                    guard let newUrl = information.next else{return}
                    mynetwork(array + Characters, newUrl, completion: completion)
                }
            
            }catch let error{
                print(error.localizedDescription)
            }
        }
        task.resume()
}
    static func myimage(_ url:String, completion: @escaping (UIImage?, Error?)->()){
        guard let myurl = URL(string: url)else {return}
        let session = URLSession.shared
        let task = session.dataTask(with: myurl){
            (data, response, error) in
            guard error == nil else{return}
            guard let httpResponse = response as? HTTPURLResponse else{return}
            guard httpResponse.statusCode == 200 else{return}
            guard let data = data else{return}
            
            guard let image = UIImage(data: data) else {
                return
            }
            completion(image,nil)
            
        }
        task.resume()
    }
    

}



    
    
           
            
            

 
    
    
    

