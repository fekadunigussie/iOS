//
//  ViewController.swift
//  Network
//
// Created by Fekadu Abebe on 9/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    var characterArray:[characters] = [] //spelled charcters wrong
    var myUrl = "https://raw.githubusercontent.com/sbassett1/swImages/master/"

 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Networking.mynetwork(characterArray, "https://swapi.co/api/people/"){[weak self] (Characters, error) in
            guard error == nil else{return}
            guard let newArray = Characters else{return}
            DispatchQueue.main.async{
                self?.characterArray += newArray
                self?.tableView.reloadData()
                
            }
        }
    }
    
    
   

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return characterArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell") else {
            fatalError("No cell created or bad identifier")
        }
        
    var name = characterArray[indexPath.row].name
       name = name?.replacingOccurrences(of: " ", with:"")
    cell.imageView?.image = #imageLiteral(resourceName: "images")
        cell.textLabel?.text = characterArray[indexPath.row].name
        guard let char_name = name else{return cell}
        
        Networking.myimage(myUrl + char_name + ".png") {[weak self] (picture,error) in
            guard error == nil else{return}
            DispatchQueue.main.async{
                cell.imageView?.image = picture
            }
            
        }
        
        
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        guard identifier == "ToDetailedView" else {return}
        guard let nextView = segue.destination as? DetailedViewController else {return}
        guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
        nextView.tempName = characterArray[indexPath.row].name
        nextView.tempHeight = characterArray[indexPath.row].height
        nextView.tempMass = characterArray[indexPath.row].mass
        // nextView.tempType = characterArray[indexPath.row].gender
        
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
}





