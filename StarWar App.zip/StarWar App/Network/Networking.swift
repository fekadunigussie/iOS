//
//  Networking.swift
//  Network
//
//  Created by Fekadu Abebe on 9/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
class Networking1{
    
}
