//
//  DetailedViewController.swift
//  Network
//
//  Created by Mac on 9/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

class DetailedViewController:UIViewController{
    
    @IBOutlet weak var charName:UILabel!
    @IBOutlet weak var charHeight:UILabel!
    @IBOutlet weak var charMass:UILabel!
    @IBOutlet weak var mImage :UIImageView!
    
    
    var tempName:String? 
    var tempHeight:String?
    var tempMass:String?
    //var tempType:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        if let temp_name = tempName{
            charName.text = "name: " + temp_name
        }
        else{charName.text = "Could not find name"}
        
        if let temp_height = tempHeight{
            charHeight.text = "Height: " + temp_height + "cm"
        }
        else{
            charHeight.text = "Not found"
        }
        
        if let temp_mass = tempMass{
            charMass.text =  "Mass: " + temp_mass + "kg"
        }
        else{
            charMass.text = "Not found"
        }
        var name = tempName
        name = name?.replacingOccurrences(of: " ", with:"")
        mImage.image = #imageLiteral(resourceName: "images")
        
        
        guard let char_name = name else{return}
        Networking.myimage("https://raw.githubusercontent.com/sbassett1/swImages/master/" + char_name + ".png") {[weak self] (picture,error) in
            guard error == nil else{return}
            DispatchQueue.main.async{
                self?.mImage.image = picture
            }
            
        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
}

    
