//
//  charactors.swift
//  Network
//
//  Created by Fekadu Abebe on 9/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
struct info:Codable{
    let next:String?
    let results:[characters]
}

struct characters:Codable{
    let name:String?
    let height:String?
    let mass:String?
//    let hair:String?
//    let skin_color:String?
//    let eye_color:String?
//    let birth_year:String?
//    let gender:String?
//    let species:String?
    
    
    /*
    init?(_ json:[String:Any]){
        
        self.name = json["name"] as? String
        self.height = json["height"] as? String
        self.hair = json["hair_color"] as? String
        self.mass = json["mass"] as? String
        self.skinCol = json["skin_color"] as? String
        self.eyeCol = json["eye_color"] as? String
        self.birthYear = json["birth_year"] as? String
       self.gender = json["gender"] as? String
        
    }*/
    
    
}
